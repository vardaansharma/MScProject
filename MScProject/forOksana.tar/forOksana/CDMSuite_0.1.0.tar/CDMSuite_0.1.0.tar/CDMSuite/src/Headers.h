#if !defined(HEADERS_INCLUDED)
#define HEADERS_INCLUDED

#include <iostream>
//#include <iomanip>
//#include <fstream>
#include <string>
#include <cstring>
#include <vector>  
//#include <queue>
//#include <stack>
#include <algorithm>

//#include <cstdio>
//#include <stdio.h>
#include "stdlib.h"
//#include "time.h"
#include <ctime>
//#include "math.h"

#include <cmath>
#include <limits>
#include <fcntl.h>
#include <ctype.h>
//#include <utility>

//reading directory stucture
//For Linux use
//#include <dirent.h>
//#include <unistd.h>
//#include <sys/stat.h>
//#include <sys/types.h>

//Numerical Recipes
//#include "nr3.h"
//#include "eigen_sym.h"

//Name spaces
using namespace std;

#endif
