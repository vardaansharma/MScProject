#ifndef HEADERS_H
#define HEADERS_H

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <cstring>
#include <vector>  
#include <queue>
#include <stack>
#include <algorithm>

#include <stdio.h>
#include "stdlib.h"
#include "time.h"
#include "math.h"

#include <cmath>
#include <limits>
#include <fcntl.h>
#include <ctype.h>

using namespace std;

#endif
